# FlatBuffers.GRPC.Swift

The following is Swift example on how GRPC would be with Swift Flatbuffers, you can simply run the following commands:

`swift run Server`

`swift run Client {port} {name}`
